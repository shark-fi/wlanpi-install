#!/usr/bin/env python3

import serial, time

portwrite = "/dev/ttyUSB2"

print("Connecting Port..")
try:
    serw = serial.Serial(portwrite, baudrate = 115200, timeout = 1,rtscts=True, dsrdtr=True)
    print("Showing LTE and 5G Bands")
    serw.write('AT+QNWPREFCFG=\"lte_band\"\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"nr5g_band\"\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\"\r'.encode())
    time.sleep(1)
#    serw.write('AT+QNWPREFCFG=\"mode_pref\"\r'.encode())
#    time.sleep(1)
#    serw.write('AT+QNWPREFCFG=\"rat_acq_order\"\r'.encode())
#    time.sleep(1)
#    serw.write('AT+QNWPREFCFG=\"nr5g_disable_mode\"\r'.encode())
#    time.sleep(1)
    list = serw.readlines()
    for i in range(0, len(list)):
        list[i] = list[i].replace(b'\n',b'').replace(b'\r',b'').replace(b'+QNWPREFCFG: ',b'').replace(b'OK',b'').replace(b'AT+QSCAN=3,1',b'')
        if(list[i] == b''):
             continue
        else:
             a = str(list[i]).replace("b'","").replace("'","").replace('"','')
             a = a.split(",")
             b = a[1].split(":")
#             print(a[0] + " " + a[1])
             print(a[0])
             print(b)
    time.sleep(1)
    serw.close()
    time.sleep(1)
except Exception as e:
    print("Serial port connection failed.")
    print(e)
