#!/bin/bash

datetime=$(date +"%Y-%m-%d_%H-%M-%S")
filename="scat_${datetime}"

pcap_file="/home/wlanpi/${filename}.pcap"
txt_file="/home/wlanpi/${filename}.txt"

scat -t qc -s /dev/ttyUSB0 -F "$pcap_file" > "$txt_file"
