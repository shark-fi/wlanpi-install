#!/bin/bash

#export PYTHONUNBUFFERED=1
#exec 2>&1
#stdbuf -oL "$0" "$@"

#./nlscan-csv wlan0

# Default values
BASH_SCRIPT=""

# Help message
show_help() {
    echo "Usage: $0 [-a | -b | -c | -d] [-h]"
    echo
    echo "Options:"
    echo "  -a    Scan wlan0"
    echo "  -b    Scan wlan1"
    echo "  -c    Scan wlan2"
    echo "  -d    Scan wlan3"
    echo "  -h    Show help"
    exit 0
}

# Parse flags
while getopts "abcdh" opt; do
    case $opt in
        a)
        # Scan All Bands and Send Cell and GPS to Grafana
            BASH_SCRIPT="nlscan-csv wlan0"
            ;;
        b)
        # Scan All Bands and Send Cell and GPS to CSV
            BASH_SCRIPT="nlscan-csv wlan1"
            ;;
        c)
        # Scan All Bands and Send Cell to CSV
            BASH_SCRIPT="nlscan-csv wlan2"
            ;;
        d)
        # Scan CBRS Band 48 and Send Cell and GPS to Grafana
            BASH_SCRIPT="nlscan-csv wlan3"
            ;;
        h)
            show_help
            ;;
        \?)
            echo "Invalid option: -$OPTARG" >&2
            show_help
            ;;
    esac
done

# Shift to get additional arguments (if any)
shift $((OPTIND - 1))

# Run the selected script or show an error if nothing was chosen
if [ -n "$BASH_SCRIPT" ]; then
#    echo "Running: $BASH_SCRIPT"
    ./$BASH_SCRIPT "$@"
    if [ $? -ne 0 ]; then
        echo "Error: Failed to execute $BASH_SCRIPT" >&2
        exit 1
    fi
else
    echo "Error: No interface selected. Use -h for help." >&2
    exit 1
fi
