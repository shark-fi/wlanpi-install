#!/usr/bin/env python3

import serial, time

portwrite = "/dev/ttyUSB2"

print("Connecting Port..")
try:
    serw = serial.Serial(portwrite, baudrate = 115200, timeout = 1,rtscts=True, dsrdtr=True)
    print("Setting to 5G NR Band n77")
    serw.write('AT+QNWPREFCFG=\"lte_band\",48\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"nr5g_band\",77\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"nsa_nr5g_band\",77\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"mode_pref\",NR5G\r'.encode())
    time.sleep(1)
    serw.write('AT+QNWPREFCFG=\"rat_acq_order\",NR5G\r'.encode())
    serw.close()
    time.sleep(1)
except Exception as e: 
    print("Serial port connection failed.")
    print(e)
